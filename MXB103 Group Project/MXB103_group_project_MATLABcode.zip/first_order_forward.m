function fdash = first_order_forward(f, n, T)
%FIRST_ORDER_FORWARD First order forward difference approximation to f'.
% FDASH = FIRST_ORDER_FORWARD(F, N, T) returns (F(i+1) - F(i)) / H
% where F is a vector, n is the number of points in F and T is the time F covers.
% FDASH should be 1 point shorter than F

h = T/n;        % find step size
fdash = zeros(1,length(f)-1);   % initiate fdash
for i = 1:length(f)-1   % Calculate derivative for each point of F
fdash(i) = (f(i+1) - f(i))./ h;
end
