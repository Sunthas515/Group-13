function [Distance_from_water,L_new,k_new] = improve_rope_constants(L,k,accuracy,T,n,g,C,m,H)
%IMPROVE_ROPE_CONSTANTS Improve the constants of bungee rope to permit a water touch
% IMPROVE_ROPE_CONSTANTS tests the value L and k as well as values ACCURACY% more or less than L and k
% T,n,g,C,m are all constants required for the Modified Euler approximation, H is the height of the platform
% The function outputs the best combination of the tested combinations (L_new and k_new),
% as well as the distance from the water of the current model
% Options which produce accelerations of over 2g are ignored
    Distance_from_water = 100;
    for i = L-L*accuracy/100:L*accuracy/100:L+L*accuracy/100    % L values being tested
        for j = k-k*accuracy/100:k*accuracy/100:k+k*accuracy/100    % k values being tested
            L_test = i;             % Length of bungee cord (m)
            k_test = j;             % Spring constant of bungee cord (N/m)
            K_test = k_test/m;      % Scaled spring constant
            f = @(t,y,v) g - C*abs(v).*v - max(0, K_test.*(y - L_test));    % Updated acceleration function
            % Modified Euler approximation of bungee jumper for new values
            [t_modeuler, y_modeuler, v_modeuler, h_modeuler] = modeuler_bungee(T, n, g, C, K_test, L_test, f);
            a_modeuler = first_order_forward(v_modeuler, n, T);     % acceleration of new model
            peaks = findpeaks(y_modeuler);  % maximum heights fallen with each cycle
            New_Distance_from_water = H-peaks(1)-2; 
            if min(a_modeuler) > -2*g  % if max acceleration is less than 2g
                % If new distance is better than previous ones, assign current values as the best ones
                if abs(New_Distance_from_water) < abs(Distance_from_water)  
                Distance_from_water = New_Distance_from_water;
                L_new = L_test;
                k_new = k_test;
                end
            end
        end
    end
end