function [x,indexes] = find_vals(F,x0)
%FIND_VALS Find_vals finds the first 2 values of F above and below x0
% It outputs the values as well as their indexes
% It assumes that F is increasing at the desired time

    i = 1;
    while(1)
        if F(i) > x0 % find first value above x0
            indexes = [i-2,i-1,i,i+1];  % store previous 2 points, current point and next point
            x = F(indexes);             % find values at each point       
            break
        else 
            i = i+1;
        end
    end
end