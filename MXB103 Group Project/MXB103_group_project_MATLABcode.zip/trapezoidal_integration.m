function integration = trapezoidal_integration(f, h)
% Takes in a function and returns the integral of it given that
% f = f(x)
% n = number of subintervals (in this case seconds)
% f(0) = a
% f(end) = b
% h = (b-a)/n;
% x = a:h:b;

%TRAPEZOIDAL_INTEGRATION trapezoidal approximation of the integral of a vector
% INTEGRATION = TRAPEZOIDAL_INTEGRATION(F, H) returns the integral of F
% where F is a vector and H is the step size of F

n = length(f);     % number of subintervals
sum = 0;           % initiate sum

% Sum middle terms
for i = 2:n
    sum = sum + f(i);
end

% Calculate final definite integral
integration = h/2 * (f(1) + 2*sum + f(end));
end